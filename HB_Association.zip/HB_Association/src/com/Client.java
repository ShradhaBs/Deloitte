package com;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.Employee;
import com.RegularEmployee;

public class Client {

	public static void main(String args[]) {

		Configuration cfg = new Configuration().configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		
		
		Transaction tx = session.beginTransaction();
        Employee employee=new Employee(1222, "Kalpana");
		session.save(employee);
		/*RegularEmployee employee=new RegularEmployee(41000,9000);
		employee.setEmployeeId(111);
		employee.setEmployeeName("Arjun");*/
		
		
		session.save(employee);
		
		

		tx.commit();
		session.close();
		System.out.println("Done");
		factory.close();

	}
}
