package com;

public class Sum {
public int addNumbers(int num1,int num2)
{
return num1+num2;
}
}

