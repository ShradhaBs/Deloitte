package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.sun.org.apache.xpath.internal.operations.Equals;

class SumTest {
Sum sum=new Sum();
	@Test
	void testAddNumbers() {
		assertEquals(100,sum.addNumbers(50,50));
	}
	

}
