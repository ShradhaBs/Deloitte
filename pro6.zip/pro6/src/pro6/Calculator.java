package pro6;
import java.util.Scanner;
public class Calculator {
	//Scanner sc=new Scanner(System.in);
public void add(int a,int b) {
	//a=sc.nextInt();
	//b=sc.nextInt();
	int res=a+b;
	System.out.println(res);
}
public void diff(double c,double d) {
	//c=sc.nextDouble();
	//d=sc.nextDouble();
	double res=c-d;
	System.out.println(res);
}
public void mul(int e,double f) {
	//e=sc.nextInt();
	//f=sc.nextDouble();
	double res=e*f;
	System.out.println(res);
}
public void div(double m,int n) {
	//m=sc.nextDouble();
	//n=sc.nextInt();
	double res=m/n;
	System.out.println(res);
	
}

public static void main(String[] args) {
	Calculator obj1=new Calculator();
	obj1.add(23,22);
	Calculator obj2=new Calculator();
	obj2.diff(23.4,22.6);
	Calculator obj3=new Calculator();
	obj3.mul(23,22.6);
	Calculator obj4=new Calculator();
	obj4.div(25.5,5);
}
}
