package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOiMPL;
import com.cms.deloitte.model.Customer;

/**
 * Servlet implementation class CustomerServlet1
 */
public class CustomerServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
int customerId=Integer.parseInt(request.getParameter("CustomerId")	);
String customerName=request.getParameter("CustomerName");	
String customerAddress=request.getParameter("CustomerAddress")	;
int billAmount=Integer.parseInt(request.getParameter("BillAmount")	);
//response.getWriter().println(cId);
//response.getWriter().println(cName);
//response.getWriter().println(cAdd);
//response.getWriter().println(cBill);
Customer customer=new Customer(customerId,customerName,customerAddress,billAmount);
CustomerDAO customerDAO =new CustomerDAOiMPL();
if(customerDAO.isCustomerExists(customerId)) {
	response.getWriter().println(customerId +"already exists");
}
else {
	customerDAO.addCustomer(customer);
	response.getWriter().println(customerName+"added succesfully");
}
}

}
