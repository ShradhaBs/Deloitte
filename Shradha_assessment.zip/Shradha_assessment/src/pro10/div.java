package pro10;


	public class div extends Arithmetic {
		@Override
		public int calc(int x, int y) {
			return (int)x/y;
		}

	}


