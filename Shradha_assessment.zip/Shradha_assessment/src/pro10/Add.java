package pro10;

public class Add extends Arithmetic {
	@Override
	public int calc(int a, int b) {
		return a+b;
	}

}
