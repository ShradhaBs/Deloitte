package pro10;

public class end extends Arithmetic {
	public int calc(int num1, int num2) {
		System.exit(0);
		return 0;
	}

}
