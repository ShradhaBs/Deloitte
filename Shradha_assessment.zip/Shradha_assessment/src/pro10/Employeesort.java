package pro10;

import java.util.Comparator;

import pro8.Customer;

public class Employeesort implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		
			// TODO Auto-generated method stub
			if((o1.getIncometax().compareTo(o2.getIncometax())>0)) {
			return 0;
			}
			else 
				return -1;
		
	}

	


	

	
	
}
