package pro10;

public class Mul extends Arithmetic {
	@Override
	public int calc(int x, int y) {
		return x*y;
	}

}
