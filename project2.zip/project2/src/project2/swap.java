package project2;

import java.util.*;


public class swap {
	public void Demo(){
	int i=0,j=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter first number:");
	i=sc.nextInt();
	System.out.println("Enter second number:");
	j=sc.nextInt();
	i=i+j;
	j=i-j;
	i=i-j;
	System.out.println("i="+i);
	System.out.println("j="+j);
	}
	public static void main(String[] args) {
	swap s=new swap();
	s.Demo();
	}
	
}
