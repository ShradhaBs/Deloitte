package com;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class AddressTag extends TagSupport
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
public int doStartTag()  throws JspException{
	JspWriter out=pageContext.getOut();
	try {
		
		out.println("Deloitte<br/>");
		out.println("Bangalore<br/>");

	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return super.doStartTag();
	}
}
