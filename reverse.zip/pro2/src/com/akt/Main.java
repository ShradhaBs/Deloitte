package com.akt;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	// write your code here
        String rev="";
        String input;
        int count=0;
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter string:");
     input=sc.next();
     for(int k=input.length()-1;k>=0;k--){
         rev=rev+input.charAt(k);

         }
         //return rev;

        System.out.println(rev);
for(int j=0;j<input.length()-1;j++){
    if(input.charAt(j)=='a'||input.charAt(j)=='e'||input.charAt(j)=='i'||input.charAt(j)=='o'||input.charAt(j)=='u'){
        count++;
        System.out.println(count);
    }
}
    }
}
