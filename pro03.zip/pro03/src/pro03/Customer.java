package pro03;

public class Customer{
public int customerId;
public String customerName;
public String customerAddress;
public int billAmount=1000;
public Customer() {
	customerId=1001;
	customerName="NA";
	 customerAddress="NA";
	 billAmount=1000;
	 }
public Customer(int customerId, String customerName, String customerAddress, int billAmount) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.customerAddress = customerAddress;
	this.billAmount = billAmount;
}
public void printDetails() {
	System.out.println(customerId);
	System.out.println(customerName);
	System.out.println(customerAddress);
	System.out.println(billAmount);
	System.out.println("Customer cons called");

}
public static void main(String[] args) {
	Customer c1=new Customer();
	c1.printDetails();
	Customer c2=new Customer(25,"abc","xyz",400);
	c2.printDetails();
}
}