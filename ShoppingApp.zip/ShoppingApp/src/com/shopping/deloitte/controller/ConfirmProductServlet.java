package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ConfirmProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletRequest session;
       
   
    public ConfirmProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @param HttpSession 
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response, HttpSession HttpSession) throws ServletException, IOException {
		// TODO Auto-generated method stubString selectedItems[]=request.getParameterValues("item");	
String[] selectedItems=request.getParameterValues("item");
HttpSession=request.getSession();
String str=(String)session.getAttribute("currentBuyer");

PrintWriter out=response.getWriter();
if(selectedItems==null) {
	response.getWriter().println("Select"+str);
	response.getWriter().println("<a href=Item.html>Go back</a>");
}
	
else {
	out.println("<h1>u selected the following:");
	for(String product:selectedItems) {
		out.println("<h1>"+product+"</h1>");
	}
}	
	
	}

}
