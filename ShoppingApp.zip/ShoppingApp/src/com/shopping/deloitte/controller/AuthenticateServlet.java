package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AuthenticateServlet
 */
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuthenticateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		PrintWriter out=response.getWriter();
		Cookie allCookies[]=request.getCookies();
		boolean alreadyVisited=false;
		if(allCookies!=null) {
		for(Cookie c:allCookies) {
			if(c.getName().equals(username)) {
				alreadyVisited=true;
				break;
			}
		}
		}
		out.println("Successfully authenticated");
		if(!alreadyVisited) {
		out.println("<h1>Welcome first time visitor,:"+username);
		Cookie cookie=new Cookie(username,username);
		response.addCookie(cookie);
		}
		else {
			out.println("<h1>Welcome anyway,you have already visited the site");

		}

		/*if(username.startsWith("T")) {
			RequestDispatcher dispatcher=request.getRequestDispatcher("Item.html");
			dispatcher.forward(request, response);
			
		}
			
		else {
			response.sendRedirect("6-6.html");
		}
	
	*/
	
	
	}

}
