package pro10;
//metadataexample
//import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class Demo {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
//load appropriate driver	
Class.forName("oracle.jdbc.driver.OracleDriver");
System.out.println("Driver Loaded");
//Obtain database connection
Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe","system","admin");

System.out.println("Connected");
//3.
java.sql.Statement stat=connection.createStatement();
ResultSet res=stat.executeQuery("select* from hr.customer");
ResultSetMetaData rsmd=res.getMetaData();
int cl=rsmd.getColumnCount();
for(int i=1;i<=cl;i++) {
	System.out.println(rsmd.getColumnLabel(i)+" ");
	}
System.out.println();
while(res.next()) {
	for(int i=1;i<=cl;i++) {
	System.out.print(res.getInt(i)+" ");
	}
	System.out.println();
	
}
stat.close();
connection.close();


	}
}
