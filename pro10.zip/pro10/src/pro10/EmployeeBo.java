package pro10;

public class EmployeeBo {
void calincomeTax(Employee e1) {
	int annualincome=e1.getAnnualincome();
	double incometax=annualincome+(0.15*annualincome);
	e1.setIncometax(incometax);
}
}
