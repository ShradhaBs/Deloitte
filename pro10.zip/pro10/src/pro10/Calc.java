package pro10;

import java.util.Scanner;

public class Calc {

	public static void main(String[] args) {
		
		Object[] arr = {new Add(), new Sub(), new Mul(), new div(), new end()};
		System.out.println("Enter your choice:1. Add 2. Sub 3. Multiply 4. Divide 5. Exit");
		int in;
		Scanner sc = new Scanner(System.in);
		in = sc.nextInt();
		int num1, num2;
		System.out.println("Enter num1: ");
		num1 = sc.nextInt();
		System.out.println("Enter num2: ");
		num2 = sc.nextInt();
		int y = ((Arithmetic)arr[in-1]).calc(num1, num2);
		System.out.println(y);
		sc.close();

	}
}
