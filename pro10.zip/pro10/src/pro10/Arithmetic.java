package pro10;

public abstract class Arithmetic {

	abstract int calc(int num1, int num2);
	
}
