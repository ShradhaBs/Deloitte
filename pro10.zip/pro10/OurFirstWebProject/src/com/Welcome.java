package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Welcome() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
    int counter=0;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
counter++;
String usern=request.getParameter("username");
String pass=request.getParameter("password");
response.getWriter().println("<h1>Welcome to my website:"+usern);
response.getWriter().println("<h1>Your password is:"+pass);

response.getWriter().println("<h1>You are visitor number:"+counter);
response.getWriter().println("<h1><a href='Shop.html'>Shop</h1>");

}

}
