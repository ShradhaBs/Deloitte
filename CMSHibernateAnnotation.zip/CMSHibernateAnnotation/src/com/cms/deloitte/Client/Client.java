package com.cms.deloitte.Client;

public class Client {
public static void main(String[] args) {
	LaunchCustomerApplication.startCustomerApp();
}
}
