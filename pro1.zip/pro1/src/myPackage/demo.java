package myPackage;
import java.util.Scanner;
public class demo {
    public int employeeId;
    public String employeeAddress;
    public String employeeName;
    public int employeeSalary;
    Scanner sc=new Scanner(System.in);
    public void toGet(){
        System.out.println("Enter employee id");
        employeeId=sc.nextInt();
        System.out.println("Enter employee address");
        employeeAddress=sc.next();
        System.out.println("Enter employee salary");
        employeeSalary=sc.nextInt();
        System.out.println("Enter employee name");
        employeeName=sc.next();

    }
    public void printEmployeeDetails(){
        System.out.println("Employee id:"+employeeId);
        System.out.println("Employee address:"+employeeAddress);
        System.out.println("Employee salary:"+employeeSalary);
        System.out.println("Employee name:"+employeeName);
    }
}
