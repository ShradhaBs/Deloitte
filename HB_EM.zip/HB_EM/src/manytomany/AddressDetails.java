package manytomany;

import java.util.Set;

public class AddressDetails {
private int addressId;
private String cityName;
public int getAddressId() {
	return addressId;
}
public AddressDetails(int addressId, String cityName, int stateSalary) {
	super();
	this.addressId = addressId;
	this.cityName = cityName;
	this.stateSalary = stateSalary;
}
public void setAddressId(int addressId) {
	this.addressId = addressId;
}
public String getCityName() {
	return cityName;
}
public void setCityName(String cityName) {
	this.cityName = cityName;
}
public int getStateSalary() {
	return stateSalary;
}
public void setStateSalary(int stateSalary) {
	this.stateSalary = stateSalary;
}
private int stateSalary;
}