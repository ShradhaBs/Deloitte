package com;

public class Apps {
public static void main(String[] args) {
	Customer customer=new Customer();
	customer.setCustomerName("Shradha");
}
}
