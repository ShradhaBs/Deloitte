package com.cms.deloitte.dbcon;

import java.sql.Connection;

public class DBConnection {

	public static Connection makeConnection() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
