package com.cms.deloitte.Client;

import java.util.Scanner;

import com.cms.deloitte.dao.impl.CustomerDAOiMPL;
import com.cms.deloitte.model.Customer;

public class LaunchCustomerApplication {
public static void startCustomerApp() {
	System.out.println("## Welcome to customer app ##");
	System.out.println("##1.Add customer ##");
	System.out.println("##2.Update Customer ##");
	System.out.println("## 3.Welcome to customer app ##");
	System.out.println("## 4.Welcome to customer app ##");
	System.out.println("## 5.Welcome to customer app ##");
	System.out.println("## 6.EXIT ##");
	Scanner sc=new Scanner(System.in);
	System.out.println("enter choice(1-6)");
	int choice=sc.nextInt();
	if(choice==1) {
		Customer customer=new Customer();
		customer.acceptCustomerDetails();
		CustomerDAOiMPL impl=new CustomerDAOiMPL();
		boolean result=impl.addCustomer(customer);
		System.out.println(result);
	}
	if(choice==6) {
		System.out.println("Thanks for using Customer app");
		System.exit(0);
	}
}
}
