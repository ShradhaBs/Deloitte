package com.dao1;

import java.util.List;

import com.model.Product;



public interface productdao1 {
	public void updateProduct(Product product);
	public List<Product> diplayproduct();

}
