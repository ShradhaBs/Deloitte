package com.dao.Impl;

import java.util.List;

import javax.security.auth.login.Configuration;



import com.dao1.productdao1;
import com.model.Product;

public class ProductDAOImpl implements productdao1{


	Configuration configuration=null;
	SessionFactory factory= null;
		
		public ProductDAOImpl() {
			
			configuration= new Configuration().configure();
			factory= configuration.buildSessionFactory();
			
		}
		

		@Override
		public void updateProduct(Product product) { {
			
			
			
			Session session= factory.openSession();
			
			Transaction transaction= session.beginTransaction();
			session.save(product);
			transaction.commit();
			session.close();
			
		}

	}

	@Override
	public List<Product> diplayproduct() {
		
			Session session= factory.openSession();
			Query query= session.createQuery("from Product");
			return query.list();
			
	}
		
		
		
	}


