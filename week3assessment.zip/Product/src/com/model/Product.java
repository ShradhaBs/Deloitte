package com.model;

import java.io.Serializable;

public class Product implements Serializable{
private String productId;
private String productName;
private String qoh;
private String price;
@Override
public String toString() {
	return "Product [productId=" + productId + ", productName=" + productName + ", qoh=" + qoh + ", price=" + price
			+ "]";
}
public Product(String productId1, String productName1, String qoh1, String price1) {
	super();
	this.productId = productId1;
	this.productName = productName1;
	this.qoh = qoh1;
	this.price = price1;
}
public String getProductId() {
	return productId;
}
public void setProductId(String productId) {
	this.productId = productId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getQoh() {
	return qoh;
}
public void setQoh(String qoh) {
	this.qoh = qoh;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
}
