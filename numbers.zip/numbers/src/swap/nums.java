package swap;
import java.util.Scanner;
public class nums {
	Scanner sc=new Scanner(System.in);
	int i,j;
	System.out.println("fhfh")
	System.out.println("Enter second number:");
	j=sc.nextInt();
	i=i+j;
	j=i-j;
	i=i-j;
	
	}
