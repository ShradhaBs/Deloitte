package oops;

public class Demo {

}
