package pro9;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomDemo {
public static void main(String[] args) throws IOException {
	RandomAccessFile file=new RandomAccessFile("C:\\Deloitte\\Batch\\today.txt", "rw");//rw is readwrite mode
file.writeUTF("Today is Friday");
System.out.println(file.getFilePointer());
//file.seek(0);//to get the pointer from the end of the line to the beginning to read
long len=file.length();
file.seek(len+1);
file.writeUTF("Shradha");//Uniform Text Format
file.seek(0);
System.out.println(file.getFilePointer());
String str=file.readLine();
file.close();
System.out.println("File content is:");
System.out.println(str);


}
}
