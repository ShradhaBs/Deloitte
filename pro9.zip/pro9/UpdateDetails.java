package pro9;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateDetails {
public static void main(String[] args) throws SQLException {
	Customer customer=new Customer();
	customer.accept();
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter customer id:");
	int cId=sc.nextInt();
	System.out.println("Enter customer name:");
	int cName=sc.nextInt();
	System.out.println("Enter customer address:");
	int cAdd=sc.nextInt();
	System.out.println("Enter customer Bill amt:");
	int cBill=sc.nextInt();
	Connection connection=DBConnection.makeConnection();
	PreparedStatement statement=connection.prepareStatement("update hr.customer values set customerName=cName,customerAddress=cAdd,CustomerBillAmount=cBill where customerId=cId)");
	
	System.out.println(customer.getCustomerName()+",your record has been saved successfully");
	
}

}
