package pro9;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableDemo {
	public static void main(String[] args) throws SQLException {
		
	
Connection connection=DBConnection.makeConnection();
Statement statement=connection.createStatement();
String query="create table hr.salary(salary integer,bonus integer)";
statement.execute(query);
System.out.println("Done");
}
}
