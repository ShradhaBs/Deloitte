package pro9;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class productInsert {
public static void main(String[] args) throws SQLException {
	Connection connection=DBConnection.makeConnection();
	Statement statement=connection.createStatement();
	/*String insertQuery="insert into hr.product values(1,'Laptop',50000,1)";
	statement.executeUpdate(insertQuery);*/
	/*String insertQuery="insert into hr.product values(2,'Chair',300,2)";
	statement.executeUpdate(insertQuery);*/
	String insertQuery="insert into hr.product values(3,'Table',200,3)";
	statement.executeUpdate(insertQuery);
	java.sql.Statement stat=connection.createStatement();
	ResultSet res=stat.executeQuery("select* from hr.product");
	while(res.next()) {
		
		System.out.print(res.getInt(1)+" ");
		System.out.print(res.getString(2)+" ");
		System.out.print(res.getString(3)+" ");
		System.out.print(res.getInt(4)+" \n");
		
		
	}
	stat.close();
}
}
