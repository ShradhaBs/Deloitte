package pro9;

public class Bank_singleton {
public static void main(String[] args) {
	Payment payment=Payment.getPaymentObject();
	payment.pay(10000);
	Payment payment2=Payment.getPaymentObject();
	payment.pay(4000);
	Payment payment3=Payment.getPaymentObject();
	payment.pay(3000);
}
}
