package pro9;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Demo2 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
//load appropriate driver	
Class.forName("oracle.jdbc.driver.OracleDriver");
System.out.println("Driver Loaded");
//Obtain database connection
Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe","system","admin");

System.out.println("Connected");
//3.
java.sql.Statement stat=connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
ResultSet res=stat.executeQuery("select hr.customer.* from hr.customer");
while(res.next()) {
	
	System.out.print(res.getInt(1)+" ");
	System.out.print(res.getString(2)+" ");
	System.out.print(res.getString(3)+" ");
	System.out.print(res.getInt(4)+"\n");
	
	
}
res.moveToInsertRow();
res.updateInt("customerId", 8);
res.updateString("customerName", "Geeta");
res.updateString("customerAddress", "Pune");
res.updateInt("billAmount", 3000);
res.insertRow();

res.absolute(2);
res.updateString(2,"Kavi");
res.updateRow();

stat.close();
connection.close();


	}
}
